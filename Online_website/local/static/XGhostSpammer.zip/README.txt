﻿XGhost Spammer V 1.0.0 is a Parallel GUI spamming program that bypass spam recognizing , mails are directly delivered to the victim's priority inbox , it was devloped in 2020 and created to be simple and easy to use .

The program is written in Python Language for Windows OS .


ATTENTION : USE THIS AT YOUR OWN GMAIL ACCOUNT PROGRAM DEVLOPER IS NOT RESPONSIBLE FOR ANY DAMAGE CAUSED BY THE PROGRAM


make sure you enable less secure apps to access your gmail account frmo your account setting (click info for more)

If you face any problems Disable your AntiVirus (click info in the program for more)


contact program Devloper at XGhost.Team0@gmail.com 


ENJOY !






















